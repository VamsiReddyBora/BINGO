import {createRequire} from 'node:module';
import {generateKeyPairSync,createHash,sign} from 'node:crypto';
import assert from 'node:assert/strict';
const require=createRequire('/home/bob/.npm/_npx/31df52248099582d/node_modules/wrangler/package.json');
const {Miniflare,convertV4MiniflareOptions}=require('miniflare');
const {build}=require('esbuild');
await build({entryPoints:['/home/bob/workspace/bingo_multiplayer/cloudflare_worker/worker.js'],outfile:'/home/bob/workspace/bingo_multiplayer/cloudflare_worker/.wrangler/smoke/worker.js',bundle:true,format:'esm',platform:'browser',target:'es2022',conditions:['workerd','worker','browser']});
const fixtures=new Map();
const mf=new Miniflare(convertV4MiniflareOptions({name:'notification-smoke',rootPath:'/home/bob/workspace/bingo_multiplayer/cloudflare_worker',modules:true,scriptPath:'/home/bob/workspace/bingo_multiplayer/cloudflare_worker/.wrangler/smoke/worker.js',compatibilityDate:'2026-01-01',
 durableObjects:{NOTIFICATIONS:{className:'NotificationInbox',useSQLite:true}},
 bindings:{GOOGLE_CLIENT_ID:'review.apps.googleusercontent.com',LEGACY_API_URL:'https://legacy.invalid/api',LEGACY_APP_KEY:'test'},
 outboundService:async request=>{const url=new URL(request.url);assert.equal(url.hostname,'legacy.invalid','No Google/FCM or production request is allowed');return Response.json(fixtures.get(decodeURIComponent(url.pathname.split('/').at(-1)))??null);}}));
function identity(name,install){const k=generateKeyPairSync('ec',{namedCurve:'prime256v1'}),pub=k.publicKey.export({type:'spki',format:'der'}),uid='guest_'+createHash('sha256').update(pub).digest('hex');return{name,install,k,pub,uid};}
async function enroll(user,sequence=1,generation='gen-one'){
 const body={provider:'guest',uid:user.uid,username:user.name,displayName:user.name,installationId:user.install,generation,sequence,token:'',timestamp:Date.now(),nonce:crypto.randomUUID(),publicKey:user.pub.toString('base64url')};
 const text=`bingo-notifications-v2\n${body.uid}\n${body.username}\n${body.installationId}\n${body.generation}\n${body.sequence}\n${body.timestamp}\n${body.nonce}`;
 body.signature=sign('sha256',Buffer.from(text),user.k.privateKey).toString('base64url');
 const r=await mf.dispatchFetch('https://relay.invalid/v2/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 assert.equal(r.status,200,await r.clone().text());return{...await r.json(),uid:user.uid,name:user.name};
}
async function call(session,path,body){return mf.dispatchFetch('https://relay.invalid'+path,{method:body===undefined?'GET':'POST',headers:session?{Authorization:'Bearer '+session.session}:{},body:body===undefined?undefined:JSON.stringify(body)});}
const results=[];
try{
 const host=identity('review_kevin','review-host-install'),guest=identity('review_stuart','review-guest-install');
 const a=await enroll(host),b=await enroll(guest);results.push('Two cryptographically verified guest sessions created through public route');
 fixtures.set('room_ABC123',{hostId:host.uid,hostUsername:host.name,status:'WAITING'});
 const now=Date.now(),event={id:'local-invite',kind:'GAME_INVITE',toUsername:guest.name,createdAt:now,expiresAt:now+120000,roomCode:'ABC123'};
 assert.equal((await call(a,'/v2/events',event)).status,202);
 let inbox=await(await call(b,'/v2/inbox')).json();assert.equal(inbox.events.length,1);assert.equal(inbox.events[0].recipientUid,b.uid);results.push('Actual SQLite-backed Durable Object persists recipient-bound invitation');
 assert.equal((await call(b,'/v2/ack',{id:event.id})).status,200);await call(a,'/v2/events',event);inbox=await(await call(b,'/v2/inbox')).json();assert.equal(inbox.events.length,0);results.push('Acknowledgement and repeated delivery preserve tombstone');
 const renewed=await enroll(guest,2,'gen-two');assert.equal((await call(b,'/v2/inbox')).status,401);assert.equal((await call(renewed,'/v2/inbox')).status,200);results.push('Generation transfer revokes prior session on actual storage');
 assert.equal((await mf.dispatchFetch('https://relay.invalid/send',{method:'POST',body:'{}'})).status,401);results.push('Legacy unauthenticated send rejected');
 console.log(JSON.stringify({result:'PASS',checks:results,realNotificationsSent:false,externalNetworkRequests:0},null,2));
}finally{await mf.dispose();}

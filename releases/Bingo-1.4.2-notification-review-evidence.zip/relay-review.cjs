const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = '/home/bob/workspace/bingo_multiplayer';
const calls = [];
let oauthCalls = 0;
const context = vm.createContext({
  Request, Response, URL, URLSearchParams, TextEncoder, Uint8Array, Date, JSON,
  btoa: s => Buffer.from(s, 'binary').toString('base64'),
  atob: s => Buffer.from(s, 'base64').toString('binary'),
  crypto: { subtle: {
    importKey: async () => ({}),
    sign: async () => new Uint8Array([1,2,3]).buffer
  }},
  fetch: async (url, options) => {
    if (url === 'https://oauth2.googleapis.com/token') {
      oauthCalls++;
      return Response.json({access_token:'MOCK_ONLY', expires_in:3600});
    }
    assert.match(url, /^https:\/\/fcm.googleapis.com\/v1\/projects\/review-only\/messages:send$/);
    calls.push(JSON.parse(options.body));
    return Response.json({name:'projects/review-only/messages/mock'});
  }
});
const source = fs.readFileSync(root+'/cloudflare_worker/worker.js','utf8')
  .replace("import serviceAccount from './service-account.json';", `const serviceAccount = {project_id:'review-only',client_email:'review@example.invalid',private_key:'-----BEGIN PRIVATE KEY-----AQID-----END PRIVATE KEY-----'};`)
  .replace('export default {','globalThis.reviewWorker = {');
vm.runInContext(source,context,{filename:'actual-worker.js'});
const results = [];
async function send(body) {
  const before = calls.length;
  const response = await context.reviewWorker.fetch(new Request('https://relay.example.invalid/send', {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)
  }), {});
  return {status:response.status, forwarded:calls.length-before};
}
(async () => {
  const fresh = {token:'SYNTHETIC_TOKEN', type:'GAME_INVITE', data:{roomCode:'REVIEW',fromUsername:'kevin',timestamp:String(Date.now())}};
  const unauthenticated = await send(fresh);
  assert.equal(unauthenticated.status,200);
  assert.equal(unauthenticated.forwarded,1);
  results.push({probe:'Unauthenticated request reaches FCM mock',actual:unauthenticated,verdict:'BUG REPRODUCED'});
  const payload = calls.at(-1).message;
  assert.equal(payload.android.priority,'HIGH');
  assert.equal(payload.android.ttl,undefined);
  results.push({probe:'Outgoing Android expiry',actual:payload.android,verdict:'No TTL configured'});
  const stale = await send({...fresh,data:{...fresh.data,timestamp:String(Date.now()-20*60*1000)}});
  assert.equal(stale.forwarded,1);
  results.push({probe:'20-minute-old invite',actual:stale,verdict:'Accepted without age validation'});
  const duplicate1 = await send(fresh);
  const duplicate2 = await send(fresh);
  assert.equal(duplicate1.forwarded+duplicate2.forwarded,2);
  results.push({probe:'Same event sent twice',actual:{forwarded:2},verdict:'No relay idempotency'});
  await send({...fresh,data:{...fresh.data,type:'FRIEND_ONLINE',username:'forged'}});
  assert.equal(calls.at(-1).message.data.type,'FRIEND_ONLINE');
  results.push({probe:'Caller-controlled data overrides declared event type',actual:{effectiveType:calls.at(-1).message.data.type},verdict:'No trusted event schema'});
  assert.equal(oauthCalls,1);
  results.push({probe:'OAuth access token reuse',actual:{mockedOAuthExchanges:oauthCalls},verdict:'CACHE WORKS'});
  results.push({scope:'Actual worker source executed with synthetic service account and mocked OAuth/FCM only. No outgoing network calls or real notification sends.'});
  fs.writeFileSync('/tmp/bingo-notification-relay-review-results.json',JSON.stringify(results,null,2)+'\n');
  console.log(JSON.stringify(results,null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
